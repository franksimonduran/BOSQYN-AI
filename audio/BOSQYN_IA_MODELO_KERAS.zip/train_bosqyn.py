import os
os.environ['KERAS_BACKEND']='torch';os.environ['OMP_NUM_THREADS']='2'
import zipfile,io,re,json,collections,hashlib
import numpy as np,soundfile as sf,librosa,keras
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import classification_report,confusion_matrix
from pathlib import Path
keras.utils.set_random_seed(42)
ROOT=Path('/mnt/data');z=zipfile.ZipFile(ROOT/'entrenamiento.zip')
classes=sorted(set(n.split('/')[0] for n in z.namelist() if n.endswith('.wav')))
X=[];Y=[];G=[];bad=[];meta=[]
for i,n in enumerate(z.namelist()):
 if not n.lower().endswith('.wav'):continue
 try:
  data,sr=sf.read(io.BytesIO(z.read(n)),dtype='float32');data=np.mean(data,axis=1) if data.ndim==2 else data
  if len(data)<sr*.5 or not np.isfinite(data).all():raise ValueError('invalid waveform')
  if sr!=16000:data=librosa.resample(data,orig_sr=sr,target_sr=16000)
  data=librosa.util.fix_length(data,size=48000)
  mel=librosa.feature.melspectrogram(y=data,sr=16000,n_fft=512,hop_length=256,n_mels=48,fmax=7500)
  feat=librosa.power_to_db(mel,ref=1.0).astype('float32')
  if feat.shape[1]!=188:feat=librosa.util.fix_length(feat,size=188,axis=1)
  X.append(feat);Y.append(classes.index(n.split('/')[0]));
  stem=Path(n).stem
  m=re.search(r'(freesound|commons|zenodo|youtube)_([^_]+)',stem)
  group=n.split('/')[0]+'_'+(m.group(0) if m else stem)
  G.append(group);meta.append({'file':n,'group':group,'sr':sr})
 except Exception as e:bad.append({'file':n,'error':str(e)})
 if i%300==0:print('processed',i,flush=True)
X=np.asarray(X,dtype='float32');Y=np.asarray(Y);G=np.asarray(G)
print('loaded',X.shape,'groups',len(set(G)),'bad',len(bad),flush=True)
# Split by original recording, stratified by class, avoiding leakage
rng=np.random.default_rng(42);splits=np.empty(len(Y),dtype='int8')
for k in range(len(classes)):
 ids=np.where(Y==k)[0];uniq=np.unique(G[ids]);rng.shuffle(uniq)
 n=len(uniq);nt=max(1,round(.15*n));nv=max(1,round(.15*n));
 if n-nt-nv<1:raise RuntimeError('too few independent recordings')
 mapping={g:(2 if j<nt else 1 if j<nt+nv else 0) for j,g in enumerate(uniq)}
 for idx in ids:splits[idx]=mapping[G[idx]]
train=np.where(splits==0)[0];val=np.where(splits==1)[0];test=np.where(splits==2)[0]
mean=float(X[train].mean());std=float(X[train].std()+1e-6)
X=np.clip((X-mean)/std,-5,5)[...,None]
model=keras.Sequential([keras.layers.Input((48,188,1)),keras.layers.Conv2D(16,3,padding='same',activation='relu'),keras.layers.MaxPooling2D(2),keras.layers.Conv2D(32,3,padding='same',activation='relu'),keras.layers.MaxPooling2D(2),keras.layers.Conv2D(64,3,padding='same',activation='relu'),keras.layers.GlobalAveragePooling2D(),keras.layers.Dense(64,activation='relu'),keras.layers.Dropout(.3),keras.layers.Dense(len(classes),activation='softmax')])
model.compile(optimizer=keras.optimizers.Adam(learning_rate=.001),loss='sparse_categorical_crossentropy',metrics=['accuracy'])
h=model.fit(X[train],Y[train],validation_data=(X[val],Y[val]),batch_size=32,epochs=8,verbose=2,callbacks=[keras.callbacks.EarlyStopping(monitor='val_loss',patience=3,restore_best_weights=True)])
path=ROOT/'bosqyn_audio.keras';model.save(path)
probs=model.predict(X[test],verbose=0);pred=probs.argmax(axis=1)
report=classification_report(Y[test],pred,labels=list(range(len(classes))),target_names=classes,zero_division=0,output_dict=True)
config={'classes':classes,'sample_rate':16000,'clip_seconds':3,'n_mels':48,'n_fft':512,'hop_length':256,'fmax':7500,'mean':mean,'std':std,'splits':{'train':len(train),'validation':len(val),'test':len(test)},'original_recordings':len(set(G)),'bad_files':bad,'test_report':report,'confusion_matrix':confusion_matrix(Y[test],pred,labels=list(range(len(classes)))).tolist(),'backend':'Keras 3 with PyTorch backend','epochs':len(h.history['loss'])}
(ROOT/'bosqyn_audio_config.json').write_text(json.dumps(config,indent=2,ensure_ascii=False))
print('RESULT',json.dumps({'accuracy':report['accuracy'],'split':config['splits'],'epochs':config['epochs'],'bad':len(bad)}),flush=True)
