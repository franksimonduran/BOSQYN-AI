import os
os.environ.setdefault('KERAS_BACKEND','torch')
import sys,json,numpy as np,soundfile as sf,librosa,keras
from pathlib import Path
root=Path(__file__).resolve().parent
cfg=json.loads((root/'bosqyn_audio_config.json').read_text())
y,sr=sf.read(sys.argv[1],dtype='float32')
if y.ndim>1:y=y.mean(axis=1)
if sr!=16000:y=librosa.resample(y,orig_sr=sr,target_sr=16000)
y=librosa.util.fix_length(y,size=48000)
mel=librosa.feature.melspectrogram(y=y,sr=16000,n_fft=512,hop_length=256,n_mels=48,fmax=7500)
feat=librosa.power_to_db(mel,ref=1.0)
feat=librosa.util.fix_length(feat,size=188,axis=1)
x=np.clip((feat-cfg['mean'])/cfg['std'],-5,5)[None,...,None].astype('float32')
model=keras.models.load_model(root/'bosqyn_audio.keras')
p=model.predict(x,verbose=0)[0]
for idx in np.argsort(p)[::-1]:print(f'{cfg["classes"][idx]}: {p[idx]:.1%}')
print('Advertencia: modelo experimental; no usar sus predicciones como evidencia de tala.')
