Bosqyn.pages.monitoreo = function (root) {
  let live = true
  let sound = true
  const btn = root.querySelector('#btn-live')
  const img = root.querySelector('#live-img')
  const badge = root.querySelector('#live-badge')
  const snd = root.querySelector('#btn-sound')
  const knob = snd.firstElementChild

  btn.addEventListener('click', () => {
    live = !live
    btn.innerHTML = (live ? Bosqyn.icons.square : Bosqyn.icons.play) + (live ? 'Detener cámara' : 'Iniciar cámara')
    img.classList.toggle('brightness-50', !live)
    img.classList.toggle('grayscale', !live)
    badge.style.display = live ? '' : 'none'
  })

  snd.addEventListener('click', () => {
    sound = !sound
    snd.classList.toggle('bg-[#22c55e]', sound)
    snd.classList.toggle('bg-white/15', !sound)
    knob.classList.toggle('left-[14px]', sound)
    knob.classList.toggle('left-[2px]', !sound)
  })
}
