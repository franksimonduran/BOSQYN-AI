Bosqyn.pages.alertas = function (root) {
  const FILTER_BASE = 'h-[27px] rounded-[7px] border px-[12px] text-[9.5px] font-medium '
  const FILTER_ON = 'border-[#22c55e] bg-[#16a34a] text-white'
  const FILTER_OFF = 'border-white/10 bg-white/[0.05] text-[#dbe6e0]'
  const PAGE_BASE = 'flex h-[28px] w-[28px] items-center justify-center rounded-[6px] border text-[10px] '
  const PAGE_ON = 'border-[#22c55e] bg-[#16a34a] font-bold text-white'
  const PAGE_OFF = 'border-white/10 bg-white/[0.05] text-[#dbe6e0]'
  const BADGE_BASE = 'inline-flex h-[20px] items-center rounded-[5px] border px-[9px] text-[9px] not-italic '
  const CONFIRMADA = 'border-[#15803d]/60 bg-[#14532d]/50 text-[#4ade80]'

  let rows = [...root.querySelectorAll('[data-row]')]
  const clsOf = (r) => r.querySelector('img').getAttribute('src').match(/a-(\w+)\.jpg/)[1]
  const filters = [...root.querySelectorAll('[data-filter]')]
  const pages = [...root.querySelectorAll('[data-pg]')]
  const count = root.querySelector('#count')
  let filter = 'todas'
  let page = 1

  function render() {
    const shown = rows.filter((r) => filter === 'todas' || clsOf(r) === filter)
    rows.forEach((r) => {
      r.style.display = shown.includes(r) ? '' : 'none'
      r.style.borderBottomWidth = ''
    })
    if (shown.length) shown[shown.length - 1].style.borderBottomWidth = '0px'
    count.textContent = `Mostrando ${shown.length} de 12 registros`
    filters.forEach((b) => (b.className = FILTER_BASE + (b.dataset.filter === filter ? FILTER_ON : FILTER_OFF)))
    pages.forEach((b) => (b.className = PAGE_BASE + (+b.dataset.pg === page ? PAGE_ON : PAGE_OFF)))
  }

  filters.forEach((b) => b.addEventListener('click', () => { filter = b.dataset.filter; render() }))
  pages.forEach((b) =>
    b.addEventListener('click', () => {
      const v = b.dataset.pg
      page = v === 'prev' ? Math.max(1, page - 1) : v === 'next' ? Math.min(3, page + 1) : +v
      render()
    }),
  )

  rows.forEach((row) => {
    const acts = row.querySelectorAll('[data-act]')
    acts[1].addEventListener('click', () => {
      const badge = row.querySelector('[data-estado]')
      badge.className = BADGE_BASE + CONFIRMADA
      badge.textContent = 'Confirmada'
    })
    acts[2].addEventListener('click', () => {
      row.remove()
      rows = rows.filter((r) => r !== row)
      render()
    })
  })
  render()
}
