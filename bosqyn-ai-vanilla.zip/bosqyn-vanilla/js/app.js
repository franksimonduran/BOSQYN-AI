;(function () {
  const REF_W = 768
  const REF_H = 512
  const app = document.getElementById('app')
  const view = document.getElementById('view')
  const hero = document.getElementById('hero')
  const header = document.getElementById('header')
  const navBtns = [...document.querySelectorAll('[data-nav]')]
  const NAV_ON = ['border-[#1fb457]/60', 'bg-gradient-to-r', 'from-[#0b7f3f]', 'to-[#12a653]', 'text-white', 'shadow-[0_0_14px_rgba(34,197,94,0.25)]']
  const NAV_OFF = ['border-transparent', 'text-[#c5d3cc]', 'hover:bg-white/5']
  const PAGES = ['inicio', 'monitoreo', 'alertas', 'estadisticas']
  let current = null

  function measure() {
    const w = window.innerWidth
    const h = window.innerHeight
    const z = w < REF_W ? 1 : Math.max(1, Math.min(w / REF_W, h / REF_H))
    app.style.zoom = z
    app.style.width = w / z + 'px'
    app.style.height = h / z + 'px'
  }

  function go(key) {
    if (!PAGES.includes(key) || key === current) return
    current = key
    view.replaceChildren(document.getElementById('tpl-' + key).content.cloneNode(true))
    hero.style.display = key === 'inicio' ? '' : 'none'
    header.classList.toggle('border-b', key !== 'inicio')
    header.classList.toggle('border-white/[0.06]', key !== 'inicio')
    navBtns.forEach((b) => {
      const on = b.dataset.nav === key
      b.classList.remove(...(on ? NAV_OFF : NAV_ON))
      b.classList.add(...(on ? NAV_ON : NAV_OFF))
    })
    if (Bosqyn.pages[key]) Bosqyn.pages[key](view)
    Bosqyn.tickClock()
  }

  navBtns.forEach((b) => b.addEventListener('click', () => go(b.dataset.nav)))
  window.addEventListener('resize', measure)
  measure()
  go('inicio')
})()
